// Copyright 2017 UNAmedia. All Rights Reserved.

#pragma once

// No public module interface.